package com.example.Formula1RacingCarChampionship;

/*Demuni Sithija Daham Nimnada De Silva
w1830147
20200479
”I confirm that I understand what plagiarism is and have read and understood the section on Assessment Offences in the Essential Information for Students. The work that I have submitted is entirely my own. Any work from other authors is duly referenced and acknowledged.”*/

interface interfaceChampionshipManager {
    void menu();
    void CreateDriver();
    void Relaunch();
    void DriverDetails();
    void DeleteDriver();
    void ChangeDriver();
    void SelectTeamChange();
    void DriverStatics();
    void DriverTable();
    void addCompleteRace();
    void saveData();
    void loadData();
}
